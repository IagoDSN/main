## Visão computacional em python com auxilio de IA

### Na linguagem(3.10.0):
![blog](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)
### Com inteligência artificial:
![blog](https://img.shields.io/badge/TensorFlow-FF6F00?style=for-the-badge&logo=tensorflow&logoColor=white)


### Comandos do CMD:

#### pip install --upgrade pip
#### pip install opencv-python
#### pip install tensorflow
#### pip install torch torchvision opencv-python-headless
#### pip install --upgrade opencv-python-headless tensorflow

###### OBS:(matenha o github em inglês ou nome de arquivos/comandos podem ser alterados).
https://www.python.org/downloads/release/python-3100/
